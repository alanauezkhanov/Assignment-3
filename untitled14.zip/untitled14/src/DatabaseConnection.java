import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class DatabaseConnection {
    private static DatabaseConnection instance;
    private String hostname;
    private String username;
    private String password;
    private String database;

    private DatabaseConnection() {
        loadConfiguration();
    }

    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }

    private void loadConfiguration() {
        Properties properties = new Properties();
        try {
            String configFile = "config.properties";
            properties.load(new FileReader(configFile));

            hostname = properties.getProperty("hostname");
            username = properties.getProperty("username");
            password = properties.getProperty("password");
            database = properties.getProperty("database");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void connect() {
        System.out.println("Connecting to the database...");
        System.out.println("Hostname: " + hostname);
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);
        System.out.println("Database: " + database);
    }

    public void executeQuery(String query) {
        System.out.println("Executing query: " + query);
    }

    public String getConnectionInfo() {
        return "Hostname: " + hostname + ", Username: " + username + ", Password: " + password + ", Database: " + database;
    }

    public static void main(String[] args) {
        DatabaseConnection dbConnection = DatabaseConnection.getInstance();

        dbConnection.connect();

        dbConnection.executeQuery("SELECT * FROM users");

        String connectionInfo = dbConnection.getConnectionInfo();
        System.out.println("Connection info: " + connectionInfo);
    }
}